package entity;

public enum Course {
    Racunarstvo,
    Informatika,
    Elektrotehnika,
    Graditeljstvo,
    Mehatronika,
    Strojarstvo
}
