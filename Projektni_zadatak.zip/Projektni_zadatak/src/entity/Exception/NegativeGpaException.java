package entity.Exception;

public class NegativeGpaException extends RuntimeException {
    public NegativeGpaException(String message) {
        super(message);
    }
}
