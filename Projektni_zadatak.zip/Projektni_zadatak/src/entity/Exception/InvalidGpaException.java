package entity.Exception;

public class InvalidGpaException extends RuntimeException {
    public InvalidGpaException(String message) {
        super(message);
    }
}
