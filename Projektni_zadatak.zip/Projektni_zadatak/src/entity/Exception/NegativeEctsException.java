package entity.Exception;

public class NegativeEctsException extends RuntimeException {
    public NegativeEctsException(String message) {
        super(message);
    }
}
