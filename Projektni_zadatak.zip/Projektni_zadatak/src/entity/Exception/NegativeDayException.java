package entity.Exception;

public class NegativeDayException extends RuntimeException {
    public NegativeDayException(String message) {
        super(message);
    }
}
