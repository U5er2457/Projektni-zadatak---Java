package app;

/**
 * Sadrži implementaciju koja pokreće glavni
 * izbornik aplikacije preko klase {@link Menu}.
 */
public class Main {

    /**
     * Ulazna statička metoda programa.
     */
    static void main() {
        new Menu().run();
    }
}
